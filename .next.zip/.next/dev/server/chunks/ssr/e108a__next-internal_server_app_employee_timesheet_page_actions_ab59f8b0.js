module.exports = [
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/.next-internal/server/app/employee/timesheet/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=e108a__next-internal_server_app_employee_timesheet_page_actions_ab59f8b0.js.map