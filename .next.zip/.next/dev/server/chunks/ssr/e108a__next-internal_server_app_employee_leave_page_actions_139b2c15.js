module.exports = [
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/.next-internal/server/app/employee/leave/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=e108a__next-internal_server_app_employee_leave_page_actions_139b2c15.js.map