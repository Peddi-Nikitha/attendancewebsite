module.exports = [
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/favicon.ico.mjs { IMAGE => \"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/favicon.ico.mjs { IMAGE => \"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/(auth)/login/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/(auth)/login/page.tsx'\n\nExpected '</', got 'numeric literal (60, 60)'");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/(auth)/login/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/app/(auth)/login/page.tsx [app-rsc] (ecmascript)"));
}),
];