module.exports = [
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/.next-internal/server/app/(auth)/login/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=e108a__next-internal_server_app_%28auth%29_login_page_actions_d94d42b7.js.map