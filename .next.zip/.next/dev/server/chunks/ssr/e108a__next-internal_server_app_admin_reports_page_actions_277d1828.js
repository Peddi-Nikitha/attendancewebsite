module.exports = [
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/.next-internal/server/app/admin/reports/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=e108a__next-internal_server_app_admin_reports_page_actions_277d1828.js.map