module.exports = [
"[project]/OneDrive/Desktop/Attendancewebsite/attendance-frontend/.next-internal/server/app/employee/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=7d09b_attendance-frontend__next-internal_server_app_employee_page_actions_229d0620.js.map