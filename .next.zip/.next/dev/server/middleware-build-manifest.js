globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a2299_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d729cb8b._.js",
    "static/chunks/a2299_next_dist_compiled_react-dom_645e1ade._.js",
    "static/chunks/a2299_next_dist_compiled_react-server-dom-turbopack_d22dec97._.js",
    "static/chunks/a2299_next_dist_compiled_next-devtools_index_14486a57.js",
    "static/chunks/a2299_next_dist_compiled_b9c25b61._.js",
    "static/chunks/a2299_next_dist_client_dab1c2a0._.js",
    "static/chunks/a2299_next_dist_aaaf6cea._.js",
    "static/chunks/11cc9_@swc_helpers_cjs_1f853cdb._.js",
    "static/chunks/OneDrive_Desktop_Attendancewebsite_attendance-frontend_a0ff3932._.js",
    "static/chunks/turbopack-OneDrive_Desktop_Attendancewebsite_attendance-frontend_7e2f2791._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];