(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/OneDrive_Desktop_Attendancewebsite_attendance-frontend_fdc4c393._.js"
],
    source: "dynamic"
});
