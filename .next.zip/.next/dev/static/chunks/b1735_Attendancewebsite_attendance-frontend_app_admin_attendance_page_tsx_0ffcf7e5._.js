(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/OneDrive_Desktop_Attendancewebsite_attendance-frontend_85d2b330._.js"
],
    source: "dynamic"
});
