(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/7d09b_attendance-frontend_lib_firebase_services_employees_ts_2ae507fa._.js",
  "static/chunks/OneDrive_Desktop_Attendancewebsite_attendance-frontend_2952653d._.js",
  "static/chunks/abf71_@firebase_auth_dist_esm_5c1e6d3e._.js",
  "static/chunks/8af4b_@firebase_firestore_dist_index_esm_b0c527ad.js",
  "static/chunks/65453_@firebase_storage_dist_index_esm_42b249d1.js",
  "static/chunks/c92c4__pnpm_ce04c720._.js"
],
    source: "dynamic"
});
