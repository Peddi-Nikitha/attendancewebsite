(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/OneDrive_Desktop_Attendancewebsite_attendance-frontend_d9d70281._.js",
  "static/chunks/85f12_recharts_es6_util_3610d5d0._.js",
  "static/chunks/85f12_recharts_es6_state_ed7a251a._.js",
  "static/chunks/85f12_recharts_es6_component_50a626c1._.js",
  "static/chunks/85f12_recharts_es6_cartesian_d0e47901._.js",
  "static/chunks/85f12_recharts_es6_1001c7bc._.js",
  "static/chunks/5f0da_d3-scale_src_6bc2211e._.js",
  "static/chunks/abf71_@firebase_auth_dist_esm_5c1e6d3e._.js",
  "static/chunks/8af4b_@firebase_firestore_dist_index_esm_b0c527ad.js",
  "static/chunks/65453_@firebase_storage_dist_index_esm_42b249d1.js",
  "static/chunks/c92c4__pnpm_abfff27b._.js"
],
    source: "dynamic"
});
