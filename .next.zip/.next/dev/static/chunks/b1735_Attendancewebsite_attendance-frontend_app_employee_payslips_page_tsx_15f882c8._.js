(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/OneDrive_Desktop_Attendancewebsite_attendance-frontend_27f5c9d2._.js"
],
    source: "dynamic"
});
